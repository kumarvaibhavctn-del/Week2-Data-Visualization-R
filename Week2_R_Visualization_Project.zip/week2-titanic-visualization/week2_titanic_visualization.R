# Week 2: Data Visualization and Insight Communication using R
# Dataset: Titanic passenger dataset (same dataset as Week 1)
# Source: https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv

packages <- c("ggplot2", "dplyr", "tidyr", "scales")
new_packages <- packages[!(packages %in% installed.packages()[, "Package"])]
if (length(new_packages) > 0) install.packages(new_packages)
invisible(lapply(packages, library, character.only = TRUE))

url <- "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/titanic.csv"
titanic <- read.csv(url, stringsAsFactors = FALSE)

# Basic preparation (same decisions as Week 1)
data <- titanic %>%
  select(-deck, -embark_town, -alive) %>%
  mutate(
    age = ifelse(is.na(age), median(age, na.rm = TRUE), age),
    embarked = ifelse(is.na(embarked),
                      names(sort(table(embarked), decreasing = TRUE))[1],
                      embarked),
    pclass = factor(pclass, levels = c(1,2,3),
                    labels = c("First", "Second", "Third")),
    survived = factor(survived, levels = c(0,1),
                      labels = c("Did not survive", "Survived")),
    sex = factor(sex)
  )

# Chart 1: Bar chart - survival rate by passenger class
class_summary <- data %>%
  group_by(pclass) %>%
  summarise(survival_rate = mean(survived == "Survived") * 100,
            passengers = n(), .groups = "drop")
p1 <- ggplot(class_summary, aes(pclass, survival_rate, fill = pclass)) +
  geom_col(show.legend = FALSE) +
  geom_text(aes(label = paste0(round(survival_rate, 1), "%")),
            vjust = -0.4) +
  scale_y_continuous(limits = c(0,100), labels = function(x) paste0(x,"%")) +
  labs(title = "Survival rate by passenger class",
       x = "Passenger class", y = "Survival rate") +
  theme_minimal()
ggsave("01_bar_survival_by_class.png", p1, width=8, height=5, dpi=300)

# Chart 2: Histogram - age distribution
p2 <- ggplot(data, aes(age)) +
  geom_histogram(binwidth=5, fill="steelblue", color="white") +
  labs(title="Distribution of passenger ages",
       x="Age (years)", y="Number of passengers") +
  theme_minimal()
ggsave("02_histogram_age.png", p2, width=8, height=5, dpi=300)

# Chart 3: Scatter plot - age versus fare, coloured by class
p3 <- ggplot(data, aes(age, fare, color=pclass)) +
  geom_point(alpha=.55) +
  labs(title="Relationship between age and ticket fare",
       x="Age (years)", y="Ticket fare", color="Passenger class") +
  theme_minimal()
ggsave("03_scatter_age_fare.png", p3, width=8, height=5, dpi=300)

# Chart 4: Line chart - survival rate by age group
age_summary <- data %>%
  mutate(age_group = cut(age, breaks=c(0,10,20,30,40,50,60,70, Inf),
                         right=FALSE,
                         labels=c("0-9","10-19","20-29","30-39",
                                  "40-49","50-59","60-69","70+"))) %>%
  group_by(age_group) %>%
  summarise(survival_rate=mean(survived=="Survived")*100,
            passengers=n(), .groups="drop")
p4 <- ggplot(age_summary, aes(age_group, survival_rate, group=1)) +
  geom_line(color="darkgreen", linewidth=1) +
  geom_point(size=2.5, color="darkgreen") +
  scale_y_continuous(limits=c(0,100), labels=function(x) paste0(x,"%")) +
  labs(title="Survival rate across age groups",
       x="Age group (years)", y="Survival rate") +
  theme_minimal()
ggsave("04_line_survival_by_age.png", p4, width=8, height=5, dpi=300)

# Chart 5: Box plot - fare distribution by class
p5 <- ggplot(data, aes(pclass, fare, fill=pclass)) +
  geom_boxplot(show.legend=FALSE, outlier.alpha=.35) +
  labs(title="Ticket fare variation across passenger classes",
       x="Passenger class", y="Ticket fare") +
  theme_minimal()
ggsave("05_boxplot_fare_by_class.png", p5, width=8, height=5, dpi=300)

# Export supporting summary tables for report evidence
write.csv(class_summary, "survival_by_class_summary.csv", row.names=FALSE)
write.csv(age_summary, "survival_by_age_group_summary.csv", row.names=FALSE)
print(class_summary)
print(age_summary)
print(summary(data$age))
print(summary(data$fare))
